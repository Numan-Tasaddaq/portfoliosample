# Responsive Portfolio Website Alexa
## [Watch it on youtube](https://youtu.be/27JtRAI3QO8)
### Responsive Portfolio Website Alexa
Responsive Portfolio Website Using Html, Css and JavaScript, With a beautiful user interface. It contains a Header, Home, About, Skills, Qualification, Services, Portfolio, Project in mind, Testimonial, Contact and Footer.
Don't forget to join the channel for more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![Resume cv](/preview.png)
